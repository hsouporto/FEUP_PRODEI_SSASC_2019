# Shared Space Simulation
